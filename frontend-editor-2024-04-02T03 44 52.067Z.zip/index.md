# HTML

# CSS

# JAVASCRIPT

*variaveis*
guardar uma informação para usar mais tarde.
const mensagem = 10 * "Olá".
*tipos de dados*
 1. tipo: number
 2. string
onde será um tipo de dado.
*funcao*
alert() - assim é iniciado uma função.

const participante = {
  nome: "Hianto Mateus",
  email: "hiantomateus@gmail.com",
  dataInscricao: new Date(2024, 2, 22, 19, 20),
  dataCheckIn: new Date(2024, 2, 25, 22, 00)
}

let participantes = [
  {
  nome: "Hianto Mateus",
  email: "hiantomateus@gmail.com",
  dataInscricao: new Date(2024, 2, 22, 19, 20),
  dataCheckIn: new Date(2024, 2, 25, 22, 00)
}
]

  // estrutura de repetição - loop
for(let participante of participantes){
    //faça alguma coisa aqui
    //enquanto estiver participantes nessa lista
  }